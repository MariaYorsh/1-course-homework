#pragma once
#ifdef L3_EXPORTS
#define L3_API __declspec(dllexport)


#else
#define L3_API __declspec(dllimport)
#endif

namespace Matrix
{
	L3_API void InitRandomMatrix(int ** matrix, int n);
	L3_API void DisplayMatrix(int ** matrix, int n);
	L3_API int ** AllocateMemory(int n, int m);
	L3_API int MaxTwo(int a, int b);
	L3_API int MinTwo(int a, int b);
	L3_API void CreateMatrix(int ** matrix, int n);
	L3_API void TransformMatrix(int ** a, int ** b, int n);
	L3_API void FreeMemory(int ** matrix, int n);
}