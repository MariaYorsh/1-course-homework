#include "stdafx.h"
#include "CppUnitTest.h"
#include "L2.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace TestMatrixSin
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			double accuracy = 0.000001;
			double x = 0.127;
			double expected = sin(x);

			
			double actual = MatrixSin::SinTaylor(x, accuracy);

			
			Assert::IsTrue(fabs(expected - actual) < accuracy);
			
		}

		TEST_METHOD(TestMethod2)
		{
			double accuracy = 0.000001;
			double x = 0.08;
			double expected = sin(x);


			double actual = MatrixSin::SinTaylor(x, accuracy);


			Assert::IsTrue(fabs(expected - actual) < accuracy);

		}


		TEST_METHOD(TestMethod3)
		{
			int n = 4;
			double** m1 = MatrixSin::AllocateMemory(n, n);
			double** m2 = MatrixSin::AllocateMemory(n, n);

			MatrixSin::InitMatrixSinTaylor(m1, n, n);
			MatrixSin::InitMatrixSin(m2, n, n);

			double max = MatrixSin::MaxDifference(m1, m2, n, n);
			double trmax = 10.0;

			Assert::AreEqual(max, trmax);

		}

		TEST_METHOD(TestMethod4)
		{
			double accuracy = 0.000001;
			double x = 1;
			double expected = exp(x);


			double actual = MatrixSin::Exponent(x, accuracy);


			Assert::AreEqual(expected, actual);

		}

		TEST_METHOD(TestMethod5)
		{
			double accuracy = 0.00001;
			double x = 4;
			double expected = exp(x);


			double actual = MatrixSin::Exponent(x, accuracy);


			Assert::IsTrue(fabs(expected - actual) < accuracy);

		}


	};
}