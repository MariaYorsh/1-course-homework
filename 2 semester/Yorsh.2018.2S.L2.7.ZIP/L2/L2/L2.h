#pragma once

#ifdef L2_EXPORTS
#define L2_API __declspec(dllexport)
#else
#define L2_API __declspec(dllimport)
#endif

namespace MatrixSin
{
	L2_API double SinTaylor(double value, double accuracy);
	L2_API double Exponent(double value, double accuracy);
	L2_API void InitMatrixSinTaylor(double** matrix, int n, int m);
	L2_API void DisplayMatrix(double ** matrix, int n, int m);
	L2_API double ** AllocateMemory(int n, int m);
	L2_API void FreeMemory(double ** matrix);
	L2_API void InitMatrixSin(double ** matrix, int n, int m);
	L2_API void MatrixCompare(double ** a, double ** b, double ** c, int n, int m);
	L2_API double MaxDifference(double ** a, double ** b, int n, int m);
}