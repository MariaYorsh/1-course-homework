 #include "stdafx.h"
#include "CppUnitTest.h"
#include "L4.h"
#include <iostream>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace ArrayL4Test
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			int n = 15;

			int* array = new int[n] {2, 43, 10, 5, 7, 8, 48, 10, 54, 30, 61, 1, 13, 35, 17};
			int* OldArray = new int[11] {43, 5, 7, 8, 10, 90, 61, 1, 13, 35, 17};
			int* NewArray = new int[n] {2, 10, 48, 54};

			int S = 4;

			Array::SeparateArray(array, OldArray, NewArray, n, S);

			for (int i = 0; i < n; i++)
			{
				Assert::AreNotEqual(array[i], OldArray[i]);
			}

		}

		TEST_METHOD(TestMethod2)
		{
			int n = 15;

			int* array = new int[n] {2, 43, 10, 5, 7, 8, 48, 10, 54, 90, 61, 1, 13, 35, 17};
			int* OldArray = new int[n] {43, 5, 7, 8, 10, 90, 61, 1, 13, 35, 17};
			int* NewArray = new int[n] {2, 10, 48, 54};

			int S = 4;

			Array::SeparateArray(array, OldArray, NewArray, n, S);

			for (int i = 0; i < n; i++)
			{
				Assert::AreNotEqual(array[i], NewArray[i]);
			}
		}
		TEST_METHOD(TestMethod3)
		{
			int n = 15;

			int* array = new int[n] {2, 43, 10, 5, 7, 8, 48, 10, 54, 90, 61, 1, 13, 35, 17};
			int* OldArray = new int[n] {43, 5, 7, 8, 10, 90, 61, 1, 13, 35, 17};
			

			int S = 4;
			int P = n - S;
			int a = 2;

			Array::BubleSortByRemainder(OldArray, P, a);

			for (int i = 0; i < n; i++) 
			{
				Assert::IsTrue(OldArray[i]%a < OldArray[i+1]%a);
			}

		}

		TEST_METHOD(TestMethod4)
		{
			int n = 20;

			int* array = new int[n] {2, 43, 10, 5, 7, 8, 48, 10, 54, 90, 61, 1, 13, 35, 17, 3, 4, 12, 23, 31};

			int num = Array::CountingElements(array, n);

			Assert::IsTrue(num == 5);

		}

	};
}