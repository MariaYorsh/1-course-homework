#pragma once

#ifdef L4_EXPORTS
#define L4_API __declspec(dllexport)


#else
#define L4_API __declspec(dllimport)
#endif

namespace Matrix
{
	L4_API void InitRandomMatrix(int ** matrix, int n, int m);
	L4_API void DisplayMatrix(int ** matrix, int n, int m);
	L4_API int ** AllocateMemory(int n, int m);
	L4_API void FreeMemory(int * array);
	L4_API int FindMin(int n, int m);
	L4_API int HalfOfTheMin(int min);
	L4_API int * AllocateArray(int n, int m);
	L4_API void InitRandomArray(int * array, int n);
	L4_API void DisplayArray(int * array, int n);
	L4_API int SumOfMatrixElements(int * array, int n,int m, int k);
}