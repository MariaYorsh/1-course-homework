#include "stdafx.h"
#include "CppUnitTest.h"
#include "L4.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace Matrix;

namespace Test_l4
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			int n = 9;
			int m = 3;

			int min = Matrix::FindMin(n, m);

			Assert::IsTrue(min == m);
		}

		TEST_METHOD(TestMethod2)
		{
			
			int min = 5;

			int k = Matrix::HalfOfTheMin(min);

			Assert::IsTrue(k == 2);
		}


	};
}