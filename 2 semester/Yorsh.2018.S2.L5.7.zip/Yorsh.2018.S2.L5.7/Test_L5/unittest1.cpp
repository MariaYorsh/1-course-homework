#include "stdafx.h"
#include "CppUnitTest.h"
#include <iostream>
#include "L5.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Test_L5
{		
	TEST_CLASS(UnitTest1)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			char  source[] = "  run night tools plane soup economy  ";
			int n = 256;
			char ** words = String::ObtainWords(source, n);
			
			int w[256];

			char f = String::FirstLetter(words, 0);
			Assert::AreEqual(f, 'r');
		}

		TEST_METHOD(TestMethod2)
		{
			char  source[] = "  run night tools plane soup economy  ";
			int n = 256;
			char ** words = String::ObtainWords(source, n);

			int w[256];

			char l = String::LastLetter(words, 0);
			Assert::AreEqual(l, 'n');
		}

		TEST_METHOD(TestMethod3)
		{
			char  source[] = "  run night tools plane soup economy  ";
			int n = 256;
			char ** words = String::ObtainWords(source, n);

			int w[256];

			char l = String::LastLetter(words, 1);
			
			int f = String::FindNextWord(words, n, l, w);

			Assert::IsTrue(words[f] == words[2]);
	};
}