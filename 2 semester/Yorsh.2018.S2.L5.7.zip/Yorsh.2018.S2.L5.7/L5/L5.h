#pragma once

#ifdef L5_EXPORTS
#define L5_API __declspec(dllexport) 
#else
#define L5_API __declspec(dllimport) 
#endif

namespace String
{
	L5_API char ** ObtainWords(char * source, int& n);
	L5_API void Swap(char*&x, char*&y);
	L5_API void ReplaceSubString(char* string, char* subString, char* replaceString);
	L5_API void DisplayWords(char** words, int n);
	L5_API void FreeHeap(char** words, int n);
	L5_API char FirstLetter(char ** words, int n);
	L5_API char LastLetter(char ** words, int n);
	L5_API int FindNextWord(char ** words, int n, char k, int * w);
}